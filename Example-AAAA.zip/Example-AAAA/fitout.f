      subroutine fit6d(r12,r13,r14,r23,r24,r34,ener,der,iop)
      implicit  real * 8 (a-h,o-z)
      dimension d123(3),d124(3),d134(3),d234(3),d1234(6),der(6)
      call diat12(r12,e12,d12,iop)
      call diat12(r13,e13,d13,iop)
      call diat12(r14,e14,d14,iop)
      call diat12(r23,e23,d23,iop)
      call diat12(r24,e24,d24,iop)
      call diat12(r34,e34,d34,iop)
      call tri123(r12,r13,r23,e123,d123,iop)
      call tri123(r12,r14,r24,e124,d124,iop)
      call tri123(r13,r14,r34,e134,d134,iop)
      call tri123(r23,r24,r34,e234,d234,iop)
      call aaaa(r12,r13,r14,r23,r24,r34,e1234,d1234,iop)
      ener=e12+e13+e14+e23+e24+e34+e123+e124+e134+e234+e1234
      der(1)=d12+d123(1)+d124(1)+d1234(1) 
      der(2)=d13+d123(2)+d134(1)+d1234(2) 
      der(3)=d14+d124(2)+d134(2)+d1234(3) 
      der(4)=d23+d123(3)+d234(1)+d1234(4) 
      der(5)=d24+d124(3)+d234(2)+d1234(5) 
      der(6)=d34+d134(3)+d234(3)+d1234(6) 
      end
************************************************************************
      subroutine diat12(r,ener,der,iop)
************************************************************************
*     This subroutine computes the energies of a diatomic potential 
*     fitted to    87 points
*     rms =      0.12232259 kcal/mol
*     emax =      0.22786653 kcal/mol
************************************************************************
      implicit real*8 (a-h,o-z)
      parameter(mt=  6,e0= 0.0000000D+00)
      parameter(vex1=    0.165794697668D+01,vex2=    0.192681061100D+01)
      dimension cf(mt)
      data cf(  1)/    0.100582819513D+01/
      data cf(  2)/   -0.328788422063D+01/
      data cf(  3)/    0.270838739227D+02/
      data cf(  4)/   -0.180248662912D+03/
      data cf(  5)/    0.647551110559D+03/
      data cf(  6)/   -0.933036634334D+03/
      aux = 1.d0/r
      bux = dexp(-vex2*r)*aux
      cux = dexp(-vex1*r)
      ener=e0+cf(1)*bux
      dux=1.d0
      eux=r*cux
      do 1 i=2,mt
         if (iop.eq.1) der=der+(i-1)*cf(i)*dux
         dux=dux*eux
         ener=ener+cf(i)*dux
    1 continue
      if (iop.eq.1) then
         der=der*(1.d0-vex1*r)*cux
         der=der-cf(1)*(vex2+aux)*bux
      endif
      return
      end
*************************************************************
      subroutine tri123(r12,r13,r23,ener,der,iop)          
*************************************************************
*     This subroutine computes the energies of a 3D PES      
*     for the AAA system class fitted to  772 points       
*     rms =      2.75207073 kcal/mol                               
*     emax=     15.25922794 kcal/mol                               
*************************************************************
      implicit real*8(a-h,o-z)                               
      parameter(is=   10, mt_1= 4)                      
      parameter(vex1=    0.123644342256D+01)                             
      dimension der(3)                                       
      dimension i1(is),i2(is),i3(is),i4(is),cf(is)           
      dimension f12(-1:mt_1),f13(-1:mt_1),f23(-1:mt_1)       
      data der12/0.d0/,der13/0.d0/,der23/0.d0/               
      data f12(-1)/0.d0/,f13(-1)/0.d0/,f23(-1)/0.d0/         
      data f12(0)/1.d0/,f13(0)/1.d0/,f23(0)/1.d0/            
      data cf(  1)/    0.107415275921D+02/
      data i1(  1)/ 0/,i2(  1)/ 1/,i3(  1)/ 1/,i4(  1)/ 3/
      data cf(  2)/    0.326393091786D+02/
      data i1(  2)/ 1/,i2(  2)/ 1/,i3(  2)/ 1/,i4(  2)/ 1/
      data cf(  3)/   -0.402182026425D+02/
      data i1(  3)/ 2/,i2(  3)/ 1/,i3(  3)/ 0/,i4(  3)/ 6/
      data cf(  4)/   -0.402791549253D+01/
      data i1(  4)/ 2/,i2(  4)/ 1/,i3(  4)/ 1/,i4(  4)/ 3/
      data cf(  5)/    0.308176096607D+03/
      data i1(  5)/ 0/,i2(  5)/ 2/,i3(  5)/ 2/,i4(  5)/ 3/
      data cf(  6)/   -0.501082348031D+02/
      data i1(  6)/ 3/,i2(  6)/ 1/,i3(  6)/ 0/,i4(  6)/ 6/
      data cf(  7)/    0.788201823838D+03/
      data i1(  7)/ 1/,i2(  7)/ 2/,i3(  7)/ 2/,i4(  7)/ 3/
      data cf(  8)/   -0.112698764807D+04/
      data i1(  8)/ 3/,i2(  8)/ 1/,i3(  8)/ 1/,i4(  8)/ 3/
      data cf(  9)/   -0.226194623589D+03/
      data i1(  9)/ 3/,i2(  9)/ 2/,i3(  9)/ 0/,i4(  9)/ 6/
      data cf( 10)/    0.284259003871D+03/
      data i1( 10)/ 4/,i2( 10)/ 1/,i3( 10)/ 0/,i4( 10)/ 6/
      ener=0.d0
      pux12=vex1*r12
      pux13=vex1*r13
      pux23=vex1*r23
      qux12=dexp(-pux12)
      qux13=dexp(-pux13)
      qux23=dexp(-pux23)
      bux12=r12*qux12
      bux13=r13*qux13
      bux23=r23*qux23
      do 1 i=1,mt_1
         f12(i)=f12(i-1)*bux12
         f13(i)=f13(i-1)*bux13
         f23(i)=f23(i-1)*bux23
1     continue

      do 2 l=1,is
         if (i4(l).eq.1) then                           
            aux=f12(i1(l))*f13(i2(l))*f23(i3(l))        
            if (iop.eq.1) then                          
               dux12=i1(l)*f12(i1(l)-1)*f13(i2(l))*f23(i3(l))
               dux13=i2(l)*f12(i1(l))*f13(i2(l)-1)*f23(i3(l))
               dux23=i3(l)*f12(i1(l))*f13(i2(l))*f23(i3(l)-1)
            endif                                    
            elseif (i4(l).eq.3) then                        
               aux1=f12(i1(l))*f13(i2(l))*f23(i3(l))    
               aux2=f12(i3(l))*f13(i1(l))*f23(i2(l))    
               aux3=f12(i3(l))*f13(i2(l))*f23(i1(l))    
               aux=aux1+aux2+aux3                    
               if (iop.eq.1) then                    
                  dux1=i1(l)*f12(i1(l)-1)*f13(i2(l))*f23(i3(l)) 
                  dux2=i3(l)*f12(i3(l)-1)*f13(i1(l))*f23(i2(l)) 
                  dux3=i2(l)*f12(i2(l)-1)*f13(i3(l))*f23(i1(l)) 
                  dux12=dux1+dux2+dux3                          
                  dux1=i2(l)*f12(i1(l))*f13(i2(l)-1)*f23(i3(l)) 
                  dux2=i1(l)*f12(i3(l))*f13(i1(l)-1)*f23(i2(l)) 
                  dux3=i3(l)*f12(i2(l))*f13(i3(l)-1)*f23(i1(l)) 
                  dux13=dux1+dux2+dux3                          
                  dux1=i3(l)*f12(i1(l))*f13(i2(l))*f23(i3(l)-1) 
                  dux2=i2(l)*f12(i3(l))*f13(i1(l))*f23(i2(l)-1) 
                  dux3=i1(l)*f12(i2(l))*f13(i3(l))*f23(i1(l)-1) 
                  dux23=dux1+dux2+dux3                          
               endif                                 
               elseif (i4(l).eq.6) then                     
                  aux1=f12(i1(l))*f13(i2(l))*f23(i3(l)) 
                  aux2=f12(i1(l))*f13(i3(l))*f23(i2(l)) 
                  aux3=f12(i2(l))*f13(i1(l))*f23(i3(l)) 
                  aux4=f12(i2(l))*f13(i3(l))*f23(i1(l)) 
                  aux5=f12(i3(l))*f13(i1(l))*f23(i2(l)) 
                  aux6=f12(i3(l))*f13(i2(l))*f23(i1(l)) 
                  aux=aux1+aux2+aux3+aux4+aux5+aux6  
                  if (iop.eq.1) then                 
                   dux1=i1(l)*f12(i1(l)-1)*f13(i2(l))*f23(i3(l))
                   dux2=i1(l)*f12(i1(l)-1)*f13(i3(l))*f23(i2(l))
                   dux3=i2(l)*f12(i2(l)-1)*f13(i1(l))*f23(i3(l))
                   dux4=i2(l)*f12(i2(l)-1)*f13(i3(l))*f23(i1(l))
                   dux5=i3(l)*f12(i3(l)-1)*f13(i1(l))*f23(i2(l))
                   dux6=i3(l)*f12(i3(l)-1)*f13(i2(l))*f23(i1(l))
                   dux12=dux1+dux2+dux3+dux4+dux5+dux6          
                   dux1=i2(l)*f12(i1(l))*f13(i2(l)-1)*f23(i3(l))
                   dux2=i3(l)*f12(i1(l))*f13(i3(l)-1)*f23(i2(l))
                   dux3=i1(l)*f12(i2(l))*f13(i1(l)-1)*f23(i3(l))
                   dux4=i3(l)*f12(i2(l))*f13(i3(l)-1)*f23(i1(l))
                   dux5=i1(l)*f12(i3(l))*f13(i1(l)-1)*f23(i2(l))
                   dux6=i2(l)*f12(i3(l))*f13(i2(l)-1)*f23(i1(l))
                   dux13=dux1+dux2+dux3+dux4+dux5+dux6          
                   dux1=i3(l)*f12(i1(l))*f13(i2(l))*f23(i3(l)-1)
                   dux2=i2(l)*f12(i1(l))*f13(i3(l))*f23(i2(l)-1)
                   dux3=i3(l)*f12(i2(l))*f13(i1(l))*f23(i3(l)-1)
                   dux4=i1(l)*f12(i2(l))*f13(i3(l))*f23(i1(l)-1)
                   dux5=i2(l)*f12(i3(l))*f13(i1(l))*f23(i2(l)-1)
                   dux6=i1(l)*f12(i3(l))*f13(i2(l))*f23(i1(l)-1)
                   dux23=dux1+dux2+dux3+dux4+dux5+dux6          
                  endif                                       
         endif                                       
         ener=ener+cf(l)*aux                         
         if (iop.eq.1) then                          
            der12=der12+cf(l)*dux12                  
            der13=der13+cf(l)*dux13                  
            der23=der23+cf(l)*dux23                  
         endif                                       
    2 continue                                     

       if (iop.eq.1) then                       
          der(1)=der12*(1.d0-pux12)*qux12       
          der(2)=der13*(1.d0-pux13)*qux13       
          der(3)=der23*(1.d0-pux23)*qux23       
       endif                                    
      return                                    
      end
*************************************************************
      subroutine   aaaa(r12,r13,r14,r23,r24,r34,ener,der,iop)
*************************************************************
*     This subroutine computes the energies of a 6D PES      
*     for the AAAA system class fitted to  850 points      
*     rms =      0.45124625 kcal/mol                               
*     emax=      2.39821218 kcal/mol                               
*************************************************************
      implicit real*8(a-h,o-z)                               
      parameter(is=   40, mt_2= 4)                      
      dimension der(6)                                       
      dimension i1(is),i2(is),i3(is),i4(is),i5(is),i6(is),i7(is),cf(is)
      common/fun4/f12(-1:mt_2),f13(-1:mt_2),f14(-1:mt_2),    
     ,            f23(-1:mt_2),f24(-1:mt_2),f34(-1:mt_2)     
      data der12/0.d0/,der13/0.d0/,der14/0.d0/               
      data der23/0.d0/,der24/0.d0/,der34/0.d0/               
      data f12(-1)/0.d0/,f13(-1)/0.d0/,f14(-1)/0.d0/         
      data f23(-1)/0.d0/,f24(-1)/0.d0/,f34(-1)/0.d0/         
      data f12(0)/1.d0/,f13(0)/1.d0/,f14(0)/1.d0/            
      data f23(0)/1.d0/,f24(0)/1.d0/,f34(0)/1.d0/            
      data cf(  1)/ 0.515082886022497632438899017870D+00/                            
      data cf(  2)/-0.941996775322669890329052577727D+02/                            
      data cf(  3)/-0.470711222260733848088420927525D+02/                            
      data cf(  4)/ 0.217066621532671859995389240794D+03/                            
      data cf(  5)/ 0.217162199871319216981646604836D+02/                            
      data cf(  6)/ 0.240115621585351675548736238852D+03/                            
      data cf(  7)/ 0.131622510447266267874510958791D+04/                            
      data cf(  8)/ 0.254557621625917022356588859111D+03/                            
      data cf(  9)/ 0.133543317083519127663748804480D+03/                            
      data cf( 10)/-0.199567155614518298989423783496D+03/                            
      data cf( 11)/ 0.105449776772026552862371318042D+03/                            
      data cf( 12)/-0.960393850313801522133871912956D+03/                            
      data cf( 13)/-0.566788276724178558652056381106D+03/                            
      data cf( 14)/ 0.394455899352398546398035250604D+03/                            
      data cf( 15)/-0.561738038732879431336186826229D+03/                            
      data cf( 16)/-0.532123802743288024430512450635D+03/                            
      data cf( 17)/ 0.161498663664684863761067390442D+04/                            
      data cf( 18)/-0.123766884524485499241563957185D+04/                            
      data cf( 19)/-0.376261376301279426570545183495D+03/                            
      data cf( 20)/-0.383462844017805764451622962952D+03/                            
      data cf( 21)/ 0.214283466335726870966027490795D+02/                            
      data cf( 22)/ 0.522575332063274913707573432475D+03/                            
      data cf( 23)/-0.101637790976544010845827870071D+03/                            
      data cf( 24)/ 0.713804073708917030671727843583D+03/                            
      data cf( 25)/-0.182056553896208765763731207699D+04/                            
      data cf( 26)/-0.643021290740994345469516701996D+03/                            
      data cf( 27)/ 0.317661671133088339047390036285D+04/                            
      data cf( 28)/-0.140094701824528374345391057432D+04/                            
      data cf( 29)/-0.298484712558983176222682232037D+03/                            
      data cf( 30)/ 0.887124799508360410982277244329D+03/                            
      data cf( 31)/ 0.205410496088408217474352568388D+04/                            
      data cf( 32)/-0.265082936507832073402823880315D+03/                            
      data cf( 33)/ 0.816111775988568297179881483316D+03/                            
      data cf( 34)/ 0.134498437738309348787879571319D+04/                            
      data cf( 35)/ 0.191275599975458908375003375113D+04/                            
      data cf( 36)/-0.432315504984116523701231926680D+04/                            
      data cf( 37)/-0.709713261342046735080657526851D+03/                            
      data cf( 38)/ 0.271888071629892692726571112871D+04/                            
      data cf( 39)/ 0.454793287770207462017424404621D+04/                            
      data cf( 40)/ 0.153205131645655019383411854506D+05/                            
      data i1(  1)/ 0/,i2(  1)/ 0/,i3(  1)/ 1/,i4(  1)/ 0/   
      data i5(  1)/ 1/,i6(  1)/ 1/,i7(  1)/24/
      data i1(  2)/ 0/,i2(  2)/ 1/,i3(  2)/ 0/,i4(  2)/ 1/   
      data i5(  2)/ 1/,i6(  2)/ 0/,i7(  2)/11/
      data i1(  3)/ 0/,i2(  3)/ 0/,i3(  3)/ 1/,i4(  3)/ 0/   
      data i5(  3)/ 1/,i6(  3)/ 2/,i7(  3)/24/
      data i1(  4)/ 0/,i2(  4)/ 0/,i3(  4)/ 1/,i4(  4)/ 1/   
      data i5(  4)/ 0/,i6(  4)/ 2/,i7(  4)/24/
      data i1(  5)/ 1/,i2(  5)/ 1/,i3(  5)/ 1/,i4(  5)/ 1/   
      data i5(  5)/ 0/,i6(  5)/ 0/,i7(  5)/13/
      data i1(  6)/ 0/,i2(  6)/ 0/,i3(  6)/ 1/,i4(  6)/ 2/   
      data i5(  6)/ 0/,i6(  6)/ 1/,i7(  6)/24/
      data i1(  7)/ 1/,i2(  7)/ 1/,i3(  7)/ 0/,i4(  7)/ 0/   
      data i5(  7)/ 1/,i6(  7)/ 1/,i7(  7)/ 3/
      data i1(  8)/ 0/,i2(  8)/ 0/,i3(  8)/ 1/,i4(  8)/ 0/   
      data i5(  8)/ 1/,i6(  8)/ 3/,i7(  8)/24/
      data i1(  9)/ 0/,i2(  9)/ 0/,i3(  9)/ 1/,i4(  9)/ 0/   
      data i5(  9)/ 2/,i6(  9)/ 2/,i7(  9)/24/
      data i1( 10)/ 0/,i2( 10)/ 0/,i3( 10)/ 1/,i4( 10)/ 1/   
      data i5( 10)/ 0/,i6( 10)/ 3/,i7( 10)/24/
      data i1( 11)/ 0/,i2( 11)/ 0/,i3( 11)/ 1/,i4( 11)/ 1/   
      data i5( 11)/ 1/,i6( 11)/ 2/,i7( 11)/24/
      data i1( 12)/ 0/,i2( 12)/ 0/,i3( 12)/ 1/,i4( 12)/ 2/   
      data i5( 12)/ 0/,i6( 12)/ 2/,i7( 12)/24/
      data i1( 13)/ 0/,i2( 13)/ 0/,i3( 13)/ 1/,i4( 13)/ 2/   
      data i5( 13)/ 1/,i6( 13)/ 1/,i7( 13)/24/
      data i1( 14)/ 0/,i2( 14)/ 0/,i3( 14)/ 1/,i4( 14)/ 3/   
      data i5( 14)/ 0/,i6( 14)/ 1/,i7( 14)/24/
      data i1( 15)/ 0/,i2( 15)/ 0/,i3( 15)/ 2/,i4( 15)/ 1/   
      data i5( 15)/ 1/,i6( 15)/ 1/,i7( 15)/24/
      data i1( 16)/ 0/,i2( 16)/ 0/,i3( 16)/ 2/,i4( 16)/ 2/   
      data i5( 16)/ 0/,i6( 16)/ 1/,i7( 16)/24/
      data i1( 17)/ 1/,i2( 17)/ 1/,i3( 17)/ 0/,i4( 17)/ 1/   
      data i5( 17)/ 1/,i6( 17)/ 1/,i7( 17)/ 6/
      data i1( 18)/ 0/,i2( 18)/ 1/,i3( 18)/ 1/,i4( 18)/ 1/   
      data i5( 18)/ 2/,i6( 18)/ 0/,i7( 18)/24/
      data i1( 19)/ 0/,i2( 19)/ 0/,i3( 19)/ 1/,i4( 19)/ 0/   
      data i5( 19)/ 1/,i6( 19)/ 4/,i7( 19)/24/
      data i1( 20)/ 0/,i2( 20)/ 0/,i3( 20)/ 1/,i4( 20)/ 0/   
      data i5( 20)/ 2/,i6( 20)/ 3/,i7( 20)/24/
      data i1( 21)/ 0/,i2( 21)/ 0/,i3( 21)/ 1/,i4( 21)/ 1/   
      data i5( 21)/ 0/,i6( 21)/ 4/,i7( 21)/24/
      data i1( 22)/ 0/,i2( 22)/ 0/,i3( 22)/ 1/,i4( 22)/ 1/   
      data i5( 22)/ 1/,i6( 22)/ 3/,i7( 22)/24/
      data i1( 23)/ 0/,i2( 23)/ 0/,i3( 23)/ 1/,i4( 23)/ 1/   
      data i5( 23)/ 2/,i6( 23)/ 2/,i7( 23)/24/
      data i1( 24)/ 0/,i2( 24)/ 0/,i3( 24)/ 1/,i4( 24)/ 2/   
      data i5( 24)/ 0/,i6( 24)/ 3/,i7( 24)/24/
      data i1( 25)/ 0/,i2( 25)/ 0/,i3( 25)/ 1/,i4( 25)/ 2/   
      data i5( 25)/ 1/,i6( 25)/ 2/,i7( 25)/24/
      data i1( 26)/ 0/,i2( 26)/ 0/,i3( 26)/ 1/,i4( 26)/ 3/   
      data i5( 26)/ 0/,i6( 26)/ 2/,i7( 26)/24/
      data i1( 27)/ 0/,i2( 27)/ 0/,i3( 27)/ 1/,i4( 27)/ 3/   
      data i5( 27)/ 1/,i6( 27)/ 1/,i7( 27)/24/
      data i1( 28)/ 0/,i2( 28)/ 0/,i3( 28)/ 1/,i4( 28)/ 4/   
      data i5( 28)/ 0/,i6( 28)/ 1/,i7( 28)/24/
      data i1( 29)/ 0/,i2( 29)/ 0/,i3( 29)/ 2/,i4( 29)/ 0/   
      data i5( 29)/ 2/,i6( 29)/ 2/,i7( 29)/24/
      data i1( 30)/ 0/,i2( 30)/ 0/,i3( 30)/ 2/,i4( 30)/ 1/   
      data i5( 30)/ 1/,i6( 30)/ 2/,i7( 30)/24/
      data i1( 31)/ 0/,i2( 31)/ 2/,i3( 31)/ 0/,i4( 31)/ 2/   
      data i5( 31)/ 2/,i6( 31)/ 0/,i7( 31)/11/
      data i1( 32)/ 0/,i2( 32)/ 0/,i3( 32)/ 2/,i4( 32)/ 2/   
      data i5( 32)/ 1/,i6( 32)/ 1/,i7( 32)/24/
      data i1( 33)/ 0/,i2( 33)/ 0/,i3( 33)/ 2/,i4( 33)/ 3/   
      data i5( 33)/ 0/,i6( 33)/ 1/,i7( 33)/24/
      data i1( 34)/ 0/,i2( 34)/ 0/,i3( 34)/ 3/,i4( 34)/ 1/   
      data i5( 34)/ 1/,i6( 34)/ 1/,i7( 34)/24/
      data i1( 35)/ 0/,i2( 35)/ 1/,i3( 35)/ 1/,i4( 35)/ 1/   
      data i5( 35)/ 1/,i6( 35)/ 2/,i7( 35)/24/
      data i1( 36)/ 0/,i2( 36)/ 1/,i3( 36)/ 1/,i4( 36)/ 1/   
      data i5( 36)/ 2/,i6( 36)/ 1/,i7( 36)/24/
      data i1( 37)/ 0/,i2( 37)/ 1/,i3( 37)/ 1/,i4( 37)/ 1/   
      data i5( 37)/ 3/,i6( 37)/ 0/,i7( 37)/24/
      data i1( 38)/ 0/,i2( 38)/ 1/,i3( 38)/ 1/,i4( 38)/ 2/   
      data i5( 38)/ 2/,i6( 38)/ 0/,i7( 38)/24/
      data i1( 39)/ 0/,i2( 39)/ 1/,i3( 39)/ 2/,i4( 39)/ 2/   
      data i5( 39)/ 1/,i6( 39)/ 0/,i7( 39)/ 6/
      data i1( 40)/ 1/,i2( 40)/ 1/,i3( 40)/ 1/,i4( 40)/ 1/   
      data i5( 40)/ 1/,i6( 40)/ 1/,i7( 40)/ 1/
      vex1=    0.118566897200D+01
      ener=0.d0          
      pux12= vex1*r12 
      pux13= vex1*r13 
      pux14= vex1*r14 
      pux23= vex1*r23 
      pux24= vex1*r24 
      pux34= vex1*r34 
      qux12= dexp(-pux12) 
      qux13= dexp(-pux13) 
      qux14= dexp(-pux14) 
      qux23= dexp(-pux23) 
      qux24= dexp(-pux24) 
      qux34= dexp(-pux34) 
      aux12= r12*qux12 
      aux13= r13*qux13 
      aux14= r14*qux14 
      aux23= r23*qux23 
      aux24= r24*qux24 
      aux34= r34*qux34 
      do 1 i=1,mt_2               
         f12(i) = aux12*f12(i-1)  
         f13(i) = aux13*f13(i-1)  
         f14(i) = aux14*f14(i-1)  
         f23(i) = aux23*f23(i-1)  
         f24(i) = aux24*f24(i-1)  
         f34(i) = aux34*f34(i-1)  
1     continue                 
      do 2 j=1,is     
         au=faaaa(i1(j),i2(j),i3(j),i4(j),i5(j),i6(j),i7(j))
         ener=ener+cf(j)*au                                 
c        if (iop.eq.1) then                                 
c           call dfaaaa(                                    
c    ,            i1(j),i2(j),i3(j),i4(j),i5(j),i6(j),i7(j),
c    ,            d12,d13,d14,d23,d24,d34)      
c           der12=der12+cf(j)*d12                          
c           der13=der13+cf(j)*d13                          
c           der14=der14+cf(j)*d14                          
c           der23=der23+cf(j)*d23                          
c           der24=der24+cf(j)*d24                          
c           der34=der34+cf(j)*d34                          
c        endif                                             
2     continue                                              
c     if (iop.eq.1) then                 
c        der(1)=der12*(1.d0-pux12)*qux12    
c        der(2)=der13*(1.d0-pux13)*qux13    
c        der(3)=der14*(1.d0-pux14)*qux14    
c        der(4)=der23*(1.d0-pux23)*qux23    
c        der(5)=der24*(1.d0-pux24)*qux24    
c        der(6)=der34*(1.d0-pux34)*qux34    
c     endif                                 
      return                                                
      end                                                   
*************************************************************
      function faaaa(i1,i2,i3,i4,i5,i6,i7)                   
      implicit real*8(a-h,o-z)                               
      parameter(mt_2= 4)                      
      common/fun4/f12(-1:mt_2),f13(-1:mt_2),f14(-1:mt_2),    
     ,            f23(-1:mt_2),f24(-1:mt_2),f34(-1:mt_2)     
      g(i,j,k,l,m,n)=f12(i)*f13(j)*f14(k)*f23(l)*f24(m)*f34(n)   
      if (i7.eq.1) then                                      
         faaaa=g(i1,i1,i1,i1,i1,i1)                          
         return                                              
      elseif (i7.eq.3) then                                  
         faaaa=g(i1,i1,i3,i3,i1,i1)+g(i1,i3,i1,i1,i3,i1)+    
     ,         g(i3,i1,i1,i1,i1,i3)                          
         return                                              
      elseif (i7.eq.4) then                                  
         faaaa=g(i1,i1,i1,i4,i4,i4)+g(i1,i4,i4,i1,i1,i4)+    
     ,         g(i4,i1,i4,i1,i4,i1)+g(i4,i4,i1,i4,i1,i1)     
         return                                              
      elseif (i7.eq.6) then                                  
         faaaa=g(i1,i2,i3,i4,i5,i6)+g(i1,i3,i2,i5,i4,i6)+    
     ,         g(i3,i1,i2,i5,i6,i4)+g(i4,i5,i6,i1,i2,i3)+    
     ,         g(i5,i4,i6,i1,i3,i2)+g(i5,i6,i4,i3,i1,i2)     
         return                                              
      elseif (i7.eq.11) then                                 
         faaaa=g(i1,i2,i3,i4,i2,i1)+g(i1,i2,i4,i3,i2,i1)+    
     ,         g(i1,i3,i2,i2,i4,i1)+g(i1,i4,i2,i2,i3,i1)+    
     ,         g(i2,i1,i3,i4,i1,i2)+g(i2,i1,i4,i3,i1,i2)+    
     ,         g(i2,i3,i1,i1,i4,i2)+g(i2,i4,i1,i1,i3,i2)+    
     ,         g(i3,i1,i2,i2,i1,i4)+g(i3,i2,i1,i1,i2,i4)+    
     ,         g(i4,i1,i2,i2,i1,i3)+g(i4,i2,i1,i1,i2,i3)     
         return                                              
      elseif (i7.eq.13) then                                 
         faaaa=g(i1,i1,i3,i4,i6,i6)+g(i1,i6,i4,i3,i1,i6)+    
     ,         g(i1,i3,i1,i6,i4,i6)+g(i1,i4,i6,i1,i3,i6)+    
     ,         g(i6,i1,i4,i3,i6,i1)+g(i6,i6,i3,i4,i1,i1)+    
     ,         g(i6,i3,i6,i1,i4,i1)+g(i6,i4,i1,i6,i3,i1)+    
     ,         g(i3,i1,i1,i6,i6,i4)+g(i3,i6,i6,i1,i1,i4)+    
     ,         g(i4,i1,i6,i1,i6,i3)+g(i4,i6,i1,i6,i1,i3)     
         return                                              
      else                                                   
         faaaa=                                              
     *  g(i6,i5,i3,i4,i2,i1)+g(i6,i4,i2,i5,i3,i1)+g(i6,i3,i5,i2,i4,i1)+                                       
     *  g(i6,i2,i4,i3,i5,i1)+g(i5,i6,i3,i4,i1,i2)+g(i5,i4,i1,i6,i3,i2)+                                       
     *  g(i5,i3,i6,i1,i4,i2)+g(i5,i1,i4,i3,i6,i2)+g(i4,i6,i2,i5,i1,i3)+                                       
     *  g(i4,i5,i1,i6,i2,i3)+g(i4,i2,i6,i1,i5,i3)+g(i4,i1,i5,i2,i6,i3)+                                       
     *  g(i3,i6,i5,i2,i1,i4)+g(i3,i5,i6,i1,i2,i4)+g(i3,i2,i1,i6,i5,i4)+                                       
     *  g(i3,i1,i2,i5,i6,i4)+g(i2,i6,i4,i3,i1,i5)+g(i2,i4,i6,i1,i3,i5)+                                       
     *  g(i2,i3,i1,i6,i4,i5)+g(i2,i1,i3,i4,i6,i5)+g(i1,i5,i4,i3,i2,i6)+                                       
     *  g(i1,i4,i5,i2,i3,i6)+g(i1,i3,i2,i5,i4,i6)+g(i1,i2,i3,i4,i5,i6)                                        
         return                                              
      endif                                                  
      return                                                 
      end                                                    
